<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BAP OPDRACHT 6</title>
</head>
<body>
<h1>BAP OPDRACHT 6</h1>
<h2>Voeg een klasgenoot toe:</h2>

<form action="verwerk_toevoeging.php" method="post">
    <label>Voornaam:
    <input type="text" name="voornaam" /></label><br>
    <label>Tussenvoegsel:
    <input type="text" name="tussenvoegsel" /></label><br>
    <label>Achternaam:
    <input type="text" name="achternaam" /></label><br>
    <label>Woonplaats:
    <input type="text" name="woonplaats" /></label><br>
    <input type="submit" name="submit" value="VOEG TOE!" />
</form>

<p>Klik <a href="index.php">hier</a> om terug te gaan...</p>

</body>
</html>