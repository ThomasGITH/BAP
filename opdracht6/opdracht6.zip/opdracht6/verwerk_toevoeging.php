<?php

    // KLASGENOOT-DATA BINNENHALEN
    $voornaam = $_POST['voornaam'];
    $tussenvoegsel =
    $achternaam =
    $woonplaats =

    // DATABASE-VARIABELEN AANMAKEN (LET OP: VERANDER JE DATABASENAAM)
    $host =
    $user =
    $password =
    $database =

    // CONNECTIE MAKEN
    $dbc =

    // QUERY (OPDRACHT) SCHRIJVEN
    $query = "INSERT INTO klasgenoten VALUES (0, '$voornaam','$tussenvoegsel','$achternaam','$woonplaats')";

    // QUERY UITVOEREN
    $result =

    // CONNECTIE SLUITEN
    $dbc_closed =

    // GEBRUIKER TERUG STUREN NAAR DE INDEX-PAGINA
    header("Location: index.php");